-- fluentway_schema.sql
-- Importe isso no seu MySQL (fluentway)

SET NAMES utf8mb4;
SET time_zone = '+00:00';

CREATE DATABASE IF NOT EXISTS fluentway CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE fluentway;

CREATE TABLE IF NOT EXISTS users (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  email VARCHAR(190) NOT NULL,
  password_hash VARCHAR(255) NULL,
  status ENUM('pending','active','blocked','deleted') NOT NULL DEFAULT 'pending',
  email_verified_at TIMESTAMP NULL,
  last_login_at TIMESTAMP NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_email (email),
  KEY idx_users_status (status)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS user_profiles (
  user_id BIGINT UNSIGNED NOT NULL,
  full_name VARCHAR(120) NULL,
  phone VARCHAR(30) NULL,
  avatar_url VARCHAR(500) NULL,
  locale VARCHAR(10) NOT NULL DEFAULT 'pt-BR',
  birthdate DATE NULL,
  notes VARCHAR(500) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id),
  CONSTRAINT fk_profiles_user FOREIGN KEY (user_id) REFERENCES users(id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS roles (
  id SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
  code VARCHAR(40) NOT NULL,
  name VARCHAR(80) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_roles_code (code)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS user_roles (
  user_id BIGINT UNSIGNED NOT NULL,
  role_id SMALLINT UNSIGNED NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, role_id),
  CONSTRAINT fk_user_roles_user FOREIGN KEY (user_id) REFERENCES users(id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_user_roles_role FOREIGN KEY (role_id) REFERENCES roles(id)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

INSERT IGNORE INTO roles (id, code, name) VALUES
  (1,'student','Aluno'),
  (2,'admin','Administrador'),
  (3,'teacher','Professor');

CREATE TABLE IF NOT EXISTS email_access_grants (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  email VARCHAR(190) NOT NULL,
  granted TINYINT(1) NOT NULL DEFAULT 1,
  source ENUM('start_button','admin_manual','import','other') NOT NULL DEFAULT 'start_button',
  granted_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  granted_by_user_id BIGINT UNSIGNED NULL,
  used_by_user_id BIGINT UNSIGNED NULL,
  used_at TIMESTAMP NULL,
  meta JSON NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_email_grant_email (email),
  KEY idx_email_grant_granted (granted, granted_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS support_widget_settings (
  id TINYINT UNSIGNED NOT NULL,
  enabled TINYINT(1) NOT NULL DEFAULT 1,
  provider ENUM('tawk','crisp','intercom','zendesk','jivochat','custom') NOT NULL DEFAULT 'tawk',
  public_key VARCHAR(255) NULL,
  secret_key VARCHAR(255) NULL,
  embed_code TEXT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB;

INSERT IGNORE INTO support_widget_settings (id, enabled, provider) VALUES (1, 0, 'tawk');
