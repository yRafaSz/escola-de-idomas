<?php
// app/lib/DB.php

final class DB {
  private static ?PDO $pdo = null;

  public static function pdo(): PDO {
    if (self::$pdo) return self::$pdo;

    $cfg = require __DIR__ . '/../config/config.php';
    $db = $cfg['db'];
    $dsn = sprintf('mysql:host=%s;dbname=%s;charset=%s', $db['host'], $db['name'], $db['charset']);

    $opt = [
      PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
      PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
      PDO::ATTR_EMULATE_PREPARES => false,
    ];

    return self::$pdo = new PDO($dsn, $db['user'], $db['pass'], $opt);
  }

  public static function one(string $sql, array $params = []): ?array {
    $st = self::pdo()->prepare($sql);
    $st->execute($params);
    $row = $st->fetch();
    return $row ?: null;
  }

  public static function all(string $sql, array $params = []): array {
    $st = self::pdo()->prepare($sql);
    $st->execute($params);
    return $st->fetchAll();
  }

  public static function exec(string $sql, array $params = []): int {
    $st = self::pdo()->prepare($sql);
    $st->execute($params);
    return $st->rowCount();
  }

  public static function lastId(): string {
    return self::pdo()->lastInsertId();
  }
}
