<?php
// app/lib/Helpers.php

function base_url(): string {
  static $cached = null;
  if ($cached !== null) return $cached;
  $cfg = require __DIR__ . '/../config/config.php';
  if (!empty($cfg['app']['base_url'])) {
    return rtrim($cfg['app']['base_url'], '/');
  }
  $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
  $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
  return $cached = $scheme . '://' . $host;
}

function redirect(string $path) {
  header('Location: ' . $path);
  exit;
}

function e(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }

function json_response($data, int $status = 200) {
  http_response_code($status);
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode($data, JSON_UNESCAPED_UNICODE);
  exit;
}

function request_json(): array {
  $raw = file_get_contents('php://input');
  if (!$raw) return [];
  $data = json_decode($raw, true);
  return is_array($data) ? $data : [];
}
