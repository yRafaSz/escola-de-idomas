<?php
// app/lib/Support.php

require_once __DIR__ . '/DB.php';

function support_embed_code(): string {
  $cfg = require __DIR__ . '/../config/config.php';

  // Preferir banco, se tiver
  try {
    $row = DB::one('SELECT enabled, embed_code FROM support_widget_settings WHERE id=1');
    if ($row && (int)$row['enabled'] === 1 && !empty($row['embed_code'])) {
      return (string)$row['embed_code'];
    }
  } catch (Throwable $e) {
    // tabela pode não existir ainda
  }

  if (!empty($cfg['support']['enabled']) && !empty($cfg['support']['embed_code'])) {
    return (string)$cfg['support']['embed_code'];
  }

  return '';
}
