<?php
// app/lib/Auth.php

require_once __DIR__ . '/DB.php';

final class Auth {
  public static function user(): ?array {
    if (empty($_SESSION['user_id'])) return null;
    $u = DB::one('SELECT id, email, status, created_at FROM users WHERE id=?', [$_SESSION['user_id']]);
    if (!$u) return null;
    $p = DB::one('SELECT full_name, phone, avatar_url FROM user_profiles WHERE user_id=?', [$u['id']]);
    return array_merge($u, ['profile' => $p ?: []]);
  }

  public static function check(): bool {
    return !empty($_SESSION['user_id']);
  }

  public static function requireLogin(): void {
    if (!self::check()) {
      redirect('/login');
    }
  }

  public static function login(int $userId): void {
    $_SESSION['user_id'] = $userId;
    DB::exec('UPDATE users SET last_login_at=NOW() WHERE id=?', [$userId]);
  }

  public static function logout(): void {
    unset($_SESSION['user_id']);
  }
}
