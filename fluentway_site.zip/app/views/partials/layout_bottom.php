

<!-- Suporte (widget externo, se você colar o código) -->
<?php $embed = support_embed_code(); if (!empty($embed)) { echo $embed; } ?>

<!-- Botão flutuante de suporte (fallback) -->
<div class="support-fab">
  <a href="/suporte">🛟 Suporte</a>
</div>

<script src="/assets/js/app.js" defer></script>
</body>
</html>
