<?php
// app/views/partials/layout_top.php
$title = $title ?? 'FluentWay';
$body_class = $body_class ?? '';
$me = Auth::user();
?><!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="csrf-token" content="<?= e(csrf_token()) ?>">
  <title><?= e($title) ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body class="<?= e($body_class) ?>">
<div class="toast-wrap" id="toastWrap" aria-live="polite" aria-atomic="true"></div>
