<?php
$title = 'Cadastro - FluentWay';
require __DIR__ . '/partials/layout_top.php';
$email_prefill = $_GET['email'] ?? '';
?>
<div class="container">
  <div class="auth-wrap">
    <div class="auth-card">
      <div class="auth-left">
        <h2>Crie sua conta</h2>
        <p>Seu e-mail precisa estar liberado pelo botão <strong>Começar</strong>.</p>
        <div class="mini">
          <span class="chip">✅ Acesso liberado</span>
          <span class="chip">🔐 Área do aluno</span>
          <span class="chip">⚡ XP</span>
        </div>
      </div>
      <div class="auth-right">
        <h1>Cadastro</h1>
        <p>Preencha para acessar o painel.</p>

        <form class="form" id="registerForm" method="post" action="/api/register">
          <?= csrf_field() ?>
          <input class="inp" name="full_name" type="text" placeholder="Nome completo" required autocomplete="name">
          <input class="inp" name="email" type="email" placeholder="E-mail" value="<?= e($email_prefill) ?>" required autocomplete="email">
          <div class="form-row">
            <input class="inp" name="password" type="password" placeholder="Senha (mín. 8)" required autocomplete="new-password">
            <input class="inp" name="password2" type="password" placeholder="Confirmar senha" required autocomplete="new-password">
          </div>
          <button class="btn btn-green" type="submit">Criar conta</button>
          <p style="font-size:13px;color:var(--text-light)">Já tem conta? <a class="muted-link" href="/login">Entrar</a></p>
        </form>
      </div>
    </div>
  </div>
</div>
<?php require __DIR__ . '/partials/layout_bottom.php'; ?>
