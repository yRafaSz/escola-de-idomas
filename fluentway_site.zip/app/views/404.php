<?php
$title = '404 - FluentWay';
require __DIR__ . '/partials/layout_top.php';
?>
<div class="container" style="padding:70px 0">
  <div class="panel" style="max-width:760px;margin:0 auto;text-align:center">
    <h2>😵 Página não encontrada</h2>
    <p style="color:var(--text-light);margin:12px 0 20px">O link que você abriu não existe.</p>
    <a class="btn btn-green" href="/">Voltar para a home</a>
  </div>
</div>
<?php require __DIR__ . '/partials/layout_bottom.php'; ?>
