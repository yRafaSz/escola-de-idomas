<?php
$title = 'Login - FluentWay';
require __DIR__ . '/partials/layout_top.php';
$email_prefill = $_GET['email'] ?? '';
?>
<div class="container">
  <div class="auth-wrap">
    <div class="auth-card">
      <div class="auth-left">
        <h2>Entre no painel</h2>
        <p>Se você já liberou o e-mail no botão <strong>Começar</strong>, é só entrar.</p>
        <div class="mini">
          <span class="chip">📚 Trilhas</span>
          <span class="chip">🏆 Conquistas</span>
          <span class="chip">📅 Horários</span>
          <span class="chip">🧾 Notas</span>
        </div>
      </div>
      <div class="auth-right">
        <h1>Login</h1>
        <p>Use seu e-mail liberado.</p>

        <form class="form" id="loginForm" method="post" action="/api/login">
          <?= csrf_field() ?>
          <input class="inp" name="email" type="email" placeholder="E-mail" value="<?= e($email_prefill) ?>" required autocomplete="email">
          <input class="inp" name="password" type="password" placeholder="Senha" required autocomplete="current-password">
          <button class="btn btn-green" type="submit">Entrar</button>
          <p style="font-size:13px;color:var(--text-light)">Não tem conta? <a class="muted-link" href="/cadastro">Criar agora</a></p>
        </form>
      </div>
    </div>
  </div>
</div>
<?php require __DIR__ . '/partials/layout_bottom.php'; ?>
