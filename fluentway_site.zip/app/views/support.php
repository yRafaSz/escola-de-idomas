<?php
$title = 'Suporte - FluentWay';
require __DIR__ . '/partials/layout_top.php';
$embed = support_embed_code();
?>
<div class="container" style="padding:40px 0 70px">
  <div class="panel" style="max-width:900px;margin:0 auto">
    <h2>🛟 Suporte</h2>
    <p style="color:var(--text-light);margin-bottom:14px">Se você já tem um widget (tawk.to / Crisp / etc.), cole o <strong>script de embed</strong> no arquivo <code>app/config/config.php</code> (ou no banco em <code>support_widget_settings</code>).</p>

    <?php if (!empty($embed)): ?>
      <div style="border:2px dashed var(--border);border-radius:14px;padding:14px">
        <p style="margin-bottom:10px"><strong>Widget carregado:</strong></p>
        <?= $embed ?>
      </div>
    <?php else: ?>
      <div style="border:2px dashed var(--border);border-radius:14px;padding:14px;background:var(--bg)">
        <p><strong>Nenhum widget configurado ainda.</strong></p>
        <p style="color:var(--text-light);margin-top:6px">Fallback: você pode deixar esse canal como página de contato e colocar WhatsApp/e-mail aqui depois.</p>
      </div>
    <?php endif; ?>

    <div style="margin-top:18px;display:flex;gap:10px;flex-wrap:wrap">
      <a class="btn btn-green" href="/">Voltar ao site</a>
      <a class="btn btn-white" href="/dashboard">Ir para o dashboard</a>
    </div>
  </div>
</div>
<?php require __DIR__ . '/partials/layout_bottom.php'; ?>
