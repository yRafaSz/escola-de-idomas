<?php
$title = 'Dashboard - FluentWay';
$body_class = 'dashboard';
require __DIR__ . '/partials/layout_top.php';
$me = Auth::user();
?>

<!-- Dashboard (HTML reaproveitado do seu layout original) -->
<?php require __DIR__ . '/partials/dashboard_content.html'; ?>

<script>
  // Pequenos placeholders para o front preencher
  window.__ME__ = <?= json_encode($me, JSON_UNESCAPED_UNICODE) ?>;
</script>

<?php require __DIR__ . '/partials/layout_bottom.php'; ?>
