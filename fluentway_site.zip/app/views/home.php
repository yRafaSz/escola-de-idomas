<?php
$title = 'FluentWay - Escola de Idiomas';
require __DIR__ . '/partials/layout_top.php';
?>

<?php require __DIR__ . '/partials/landing_content.html'; ?>

<!-- Modal: Começar (libera e-mail) -->
<div class="modal" id="startModal" role="dialog" aria-modal="true" aria-labelledby="startTitle">
  <div class="modal-card">
    <div class="modal-hd">
      <h3 id="startTitle">🚀 Começar agora</h3>
      <button class="icon-btn" data-close-modal="startModal" aria-label="Fechar">✕</button>
    </div>
    <div class="modal-bd">
      <p style="color:var(--text-light);margin-bottom:12px">Digite seu e-mail para liberar o acesso ao painel do aluno.</p>
      <input class="inp" id="startEmailModal" type="email" placeholder="seuemail@exemplo.com" autocomplete="email">
      <p style="font-size:12px;color:var(--text-light);margin-top:10px">Ao continuar, você concorda em receber comunicações sobre as aulas.</p>
    </div>
    <div class="modal-ft">
      <button class="btn btn-white" data-close-modal="startModal">Cancelar</button>
      <button class="btn btn-green" id="btnStartModal">Liberar acesso</button>
    </div>
  </div>
</div>

<?php require __DIR__ . '/partials/layout_bottom.php'; ?>
