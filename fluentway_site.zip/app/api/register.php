<?php
// app/api/register.php

declare(strict_types=1);

require_once __DIR__ . '/../bootstrap.php';
csrf_verify();

$email = strtolower(trim($_POST['email'] ?? ''));
$full_name = trim($_POST['full_name'] ?? '');
$pw = $_POST['password'] ?? '';
$pw2 = $_POST['password2'] ?? '';

if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
  json_response(['ok'=>false,'error'=>'E-mail inválido.'], 422);
}
if (mb_strlen($full_name) < 3) {
  json_response(['ok'=>false,'error'=>'Informe seu nome completo.'], 422);
}
if (strlen($pw) < 8) {
  json_response(['ok'=>false,'error'=>'Senha deve ter no mínimo 8 caracteres.'], 422);
}
if ($pw !== $pw2) {
  json_response(['ok'=>false,'error'=>'As senhas não conferem.'], 422);
}

// Checar se e-mail foi liberado pelo "Começar"
$grant = DB::one('SELECT granted FROM email_access_grants WHERE email=?', [$email]);
if (!$grant || (int)$grant['granted'] !== 1) {
  json_response(['ok'=>false,'error'=>'Seu e-mail ainda não foi liberado. Clique em "Começar" na home primeiro.'], 403);
}

$exists = DB::one('SELECT id FROM users WHERE email=?', [$email]);
if ($exists) {
  json_response(['ok'=>false,'error'=>'Já existe uma conta com esse e-mail. Faça login.'], 409);
}

$hash = password_hash($pw, PASSWORD_BCRYPT);
DB::exec('INSERT INTO users (email, password_hash, status, email_verified_at, created_at) VALUES (?, ?, \'active\', NOW(), NOW())', [$email, $hash]);
$userId = (int)DB::lastId();
DB::exec('INSERT INTO user_profiles (user_id, full_name, created_at) VALUES (?, ?, NOW())', [$userId, $full_name]);
DB::exec('INSERT IGNORE INTO user_roles (user_id, role_id, created_at) VALUES (?, 1, NOW())', [$userId]);

// marca o grant como usado
DB::exec('UPDATE email_access_grants SET used_by_user_id=?, used_at=NOW() WHERE email=?', [$userId, $email]);

Auth::login($userId);
json_response(['ok'=>true,'redirect'=>'/dashboard']);
