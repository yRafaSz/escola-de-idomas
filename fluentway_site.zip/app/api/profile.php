<?php
// app/api/profile.php

declare(strict_types=1);

require_once __DIR__ . '/../bootstrap.php';
csrf_verify_header();

$me = Auth::user();
if (!$me) json_response(['ok'=>false,'error'=>'Não autenticado'], 401);

$data = request_json();
$full_name = trim($data['full_name'] ?? '');
$phone = trim($data['phone'] ?? '');

if (mb_strlen($full_name) < 3) {
  json_response(['ok'=>false,'error'=>'Nome inválido.'], 422);
}

DB::exec(
  'INSERT INTO user_profiles (user_id, full_name, phone, updated_at) VALUES (?, ?, ?, NOW())
   ON DUPLICATE KEY UPDATE full_name=VALUES(full_name), phone=VALUES(phone), updated_at=NOW()',
  [(int)$me['id'], $full_name, $phone]
);

json_response(['ok'=>true]);
