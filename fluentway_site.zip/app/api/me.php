<?php
// app/api/me.php

declare(strict_types=1);

require_once __DIR__ . '/../bootstrap.php';

$me = Auth::user();
if (!$me) json_response(['ok'=>false,'error'=>'Não autenticado'], 401);

json_response(['ok'=>true,'me'=>$me]);
