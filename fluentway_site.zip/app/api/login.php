<?php
// app/api/login.php

declare(strict_types=1);

require_once __DIR__ . '/../bootstrap.php';
csrf_verify();

$email = strtolower(trim($_POST['email'] ?? ''));
$pw = $_POST['password'] ?? '';

if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
  json_response(['ok'=>false,'error'=>'E-mail inválido.'], 422);
}

$u = DB::one('SELECT id, password_hash, status FROM users WHERE email=?', [$email]);
if (!$u || empty($u['password_hash']) || !password_verify($pw, $u['password_hash'])) {
  json_response(['ok'=>false,'error'=>'E-mail ou senha inválidos.'], 401);
}
if ($u['status'] !== 'active') {
  json_response(['ok'=>false,'error'=>'Conta não está ativa.'], 403);
}

// exigir que e-mail tenha grant
$grant = DB::one('SELECT granted FROM email_access_grants WHERE email=?', [$email]);
if (!$grant || (int)$grant['granted'] !== 1) {
  json_response(['ok'=>false,'error'=>'Seu e-mail não está liberado. Clique em "Começar" na home primeiro.'], 403);
}

Auth::login((int)$u['id']);
json_response(['ok'=>true,'redirect'=>'/dashboard']);
