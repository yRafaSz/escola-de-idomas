<?php
// app/api/password.php

declare(strict_types=1);

require_once __DIR__ . '/../bootstrap.php';
csrf_verify_header();

$me = Auth::user();
if (!$me) json_response(['ok'=>false,'error'=>'Não autenticado'], 401);

$data = request_json();
$cur = (string)($data['current_password'] ?? '');
$new = (string)($data['new_password'] ?? '');

if (strlen($new) < 8) {
  json_response(['ok'=>false,'error'=>'Nova senha deve ter no mínimo 8 caracteres.'], 422);
}

$u = DB::one('SELECT id, password_hash FROM users WHERE id=?', [(int)$me['id']]);
if (!$u || empty($u['password_hash']) || !password_verify($cur, $u['password_hash'])) {
  json_response(['ok'=>false,'error'=>'Senha atual incorreta.'], 401);
}

$hash = password_hash($new, PASSWORD_BCRYPT);
DB::exec('UPDATE users SET password_hash=?, updated_at=NOW() WHERE id=?', [$hash, (int)$me['id']]);

json_response(['ok'=>true]);
