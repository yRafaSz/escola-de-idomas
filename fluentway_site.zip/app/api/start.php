<?php
// app/api/start.php

declare(strict_types=1);

require_once __DIR__ . '/../bootstrap.php';
csrf_verify_header();

$data = request_json();
$email = strtolower(trim($data['email'] ?? ''));

if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
  json_response(['ok'=>false,'error'=>'E-mail inválido.'], 422);
}

// Cria grant se não existir
DB::exec(
  'INSERT INTO email_access_grants (email, granted, source, granted_at) VALUES (?, 1, \'start_button\', NOW())
   ON DUPLICATE KEY UPDATE granted=1, source=\'start_button\'',
  [$email]
);

json_response([
  'ok' => true,
  'next' => [
    'register_url' => '/cadastro?email=' . urlencode($email),
    'login_url' => '/login?email=' . urlencode($email)
  ]
]);
