<?php
// app/config/config.php
// Ajuste com os dados do seu servidor
return [
  'app' => [
    'name' => 'FluentWay',
    'base_url' => '', // ex: https://seusite.com (vazio = auto)
    'session_name' => 'fluentway_session',
  ],
  'db' => [
    'host' => 'localhost',
    'name' => 'fluentway',
    'user' => 'root',
    'pass' => '',
    'charset' => 'utf8mb4',
  ],
  // Suporte: cole aqui o embed code do seu provedor (tawk.to, crisp, etc.)
  // Você também pode configurar no banco (tabela support_widget_settings). Se existir no banco, ele sobrescreve.
  'support' => [
    'enabled' => true,
    'embed_code' => ''
  ],
];
