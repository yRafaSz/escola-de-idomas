<?php
// app/bootstrap.php

declare(strict_types=1);

$cfg = require __DIR__ . '/config/config.php';

session_name($cfg['app']['session_name'] ?? 'fluentway_session');
session_start();

require_once __DIR__ . '/lib/Helpers.php';
require_once __DIR__ . '/lib/Csrf.php';
require_once __DIR__ . '/lib/DB.php';
require_once __DIR__ . '/lib/Auth.php';
require_once __DIR__ . '/lib/Support.php';
