<?php
// public/index.php

declare(strict_types=1);

require_once __DIR__ . '/../app/bootstrap.php';

$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

// Normalizar (tirar barra final, exceto raiz)
if ($path !== '/' && str_ends_with($path, '/')) {
  $path = rtrim($path, '/');
}

// Rotas
switch (true) {
  // Páginas
  case $method === 'GET' && $path === '/':
    require __DIR__ . '/../app/views/home.php';
    break;

  case $method === 'GET' && $path === '/login':
    require __DIR__ . '/../app/views/login.php';
    break;

  case $method === 'GET' && $path === '/cadastro':
    require __DIR__ . '/../app/views/register.php';
    break;

  case $method === 'GET' && $path === '/dashboard':
    Auth::requireLogin();
    require __DIR__ . '/../app/views/dashboard.php';
    break;

  case $method === 'GET' && $path === '/logout':
    Auth::logout();
    redirect('/');
    break;

  case $method === 'GET' && $path === '/suporte':
    require __DIR__ . '/../app/views/support.php';
    break;

  // API
  case $path === '/api/start' && $method === 'POST':
    require __DIR__ . '/../app/api/start.php';
    break;

  case $path === '/api/register' && $method === 'POST':
    require __DIR__ . '/../app/api/register.php';
    break;

  case $path === '/api/login' && $method === 'POST':
    require __DIR__ . '/../app/api/login.php';
    break;

  case $path === '/api/me' && $method === 'GET':
    require __DIR__ . '/../app/api/me.php';
    break;


  case $path === '/api/profile' && $method === 'POST':
    Auth::requireLogin();
    require __DIR__ . '/../app/api/profile.php';
    break;

  case $path === '/api/password' && $method === 'POST':
    Auth::requireLogin();
    require __DIR__ . '/../app/api/password.php';
    break;

  case $path === '/api/logout' && $method === 'POST':
    Auth::logout();
    json_response(['ok' => true]);
    break;

  default:
    http_response_code(404);
    require __DIR__ . '/../app/views/404.php';
}
