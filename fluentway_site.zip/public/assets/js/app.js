(() => {
  const $ = (sel, el=document) => el.querySelector(sel);
  const $$ = (sel, el=document) => [...el.querySelectorAll(sel)];

  const csrf = () => (document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '');

  const toastWrap = () => document.getElementById('toastWrap');
  function toast(type, title, msg) {
    const wrap = toastWrap();
    if (!wrap) return;
    const t = document.createElement('div');
    t.className = `toast ${type === 'ok' ? 'ok' : 'err'}`;
    t.innerHTML = `
      <div class="t-ic">${type === 'ok' ? '✅' : '⚠️'}</div>
      <div>
        <strong>${title}</strong>
        <p>${msg}</p>
      </div>
    `;
    wrap.appendChild(t);
    setTimeout(() => t.remove(), 4500);
  }

  // ----------------------------
  // Modal helpers
  // ----------------------------
  function openModal(id) {
    const m = document.getElementById(id);
    if (!m) return;
    m.classList.add('show');
    document.body.style.overflow = 'hidden';
  }
  function closeModal(id) {
    const m = document.getElementById(id);
    if (!m) return;
    m.classList.remove('show');
    document.body.style.overflow = '';
  }

  document.addEventListener('click', (ev) => {
    const btn = ev.target.closest('[data-close-modal]');
    if (btn) {
      closeModal(btn.getAttribute('data-close-modal'));
      return;
    }
    // click outside
    if (ev.target.classList?.contains('modal')) {
      ev.target.classList.remove('show');
      document.body.style.overflow = '';
    }
  });

  // ----------------------------
  // HOME: botão começar
  // ----------------------------
  const btnStart = document.getElementById('btnStart');
  if (btnStart) {
    btnStart.addEventListener('click', async (ev) => {
      ev.preventDefault();
      // abre modal e preenche com o campo do CTA
      const ctaEmail = document.getElementById('startEmail')?.value || '';
      const modalInp = document.getElementById('startEmailModal');
      if (modalInp && ctaEmail) modalInp.value = ctaEmail;
      openModal('startModal');
      setTimeout(() => modalInp?.focus(), 50);
    });
  }

  const btnStartModal = document.getElementById('btnStartModal');
  if (btnStartModal) {
    btnStartModal.addEventListener('click', async () => {
      const email = (document.getElementById('startEmailModal')?.value || '').trim().toLowerCase();
      if (!email) {
        toast('err','E-mail','Digite seu e-mail.');
        return;
      }
      try {
        btnStartModal.disabled = true;
        btnStartModal.textContent = 'Liberando...';

        const res = await fetch('/api/start', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-CSRF-Token': csrf(),
          },
          body: JSON.stringify({ email })
        });
        const out = await res.json();
        if (!res.ok || !out.ok) {
          throw new Error(out.error || 'Falha ao liberar acesso.');
        }
        toast('ok','Acesso liberado','Agora crie sua conta ou faça login.');
        closeModal('startModal');
        // vai pro cadastro com e-mail preenchido
        window.location.href = out.next?.register_url || `/cadastro?email=${encodeURIComponent(email)}`;
      } catch (e) {
        toast('err','Erro', e.message || 'Tente novamente.');
      } finally {
        btnStartModal.disabled = false;
        btnStartModal.textContent = 'Liberar acesso';
      }
    });
  }

  // ----------------------------
  // Forms: login/cadastro (AJAX)
  // ----------------------------
  async function formToJson(form) {
    const fd = new FormData(form);
    const obj = {};
    for (const [k,v] of fd.entries()) obj[k] = v;
    return obj;
  }

  async function handleAuthForm(form) {
    form.addEventListener('submit', async (ev) => {
      ev.preventDefault();
      const action = form.getAttribute('action');
      const fd = new FormData(form);

      try {
        const res = await fetch(action, { method: 'POST', body: fd });
        const out = await res.json();
        if (!res.ok || !out.ok) throw new Error(out.error || 'Falha.');
        toast('ok','Tudo certo','Redirecionando...');
        window.location.href = out.redirect || '/dashboard';
      } catch (e) {
        toast('err','Erro', e.message || 'Verifique os dados.');
      }
    });
  }

  const loginForm = document.getElementById('loginForm');
  if (loginForm) handleAuthForm(loginForm);

  const registerForm = document.getElementById('registerForm');
  if (registerForm) handleAuthForm(registerForm);

  // ----------------------------
  // DASHBOARD: carrossel + tabs + animações
  // ----------------------------
  // (reaproveita a lógica do seu HTML original)

  // Tabs
  window.switchTab = (name, el) => {
    $$('.dash-tab').forEach(t => t.classList.remove('active'));
    $$('.nv').forEach(n => n.classList.remove('active'));
    const tab = document.getElementById('tab-' + name);
    if (tab) tab.classList.add('active');
    if (el) el.classList.add('active');
  };

  // Carrossel
  const track = document.getElementById('slidesTrack');
  const dots = $$('.dot');
  let curSlide = 0;
  const totalSlides = dots.length || 5;

  window.goSlide = (n) => {
    if (!track) return;
    curSlide = n;
    track.style.transform = `translateX(-${curSlide * 100}%)`;
    dots.forEach((d, i) => d.classList.toggle('active', i === curSlide));
  };

  window.moveCar = (step) => {
    if (!track) return;
    curSlide = (curSlide + step + totalSlides) % totalSlides;
    window.goSlide(curSlide);
  };

  if (track) {
    setInterval(() => window.moveCar(1), 5000);
  }

  // Animate bars when visible
  const panels = $$('.panel,.grades-summary');
  if (panels.length) {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(e => {
        if (e.isIntersecting) {
          e.target.querySelectorAll('.sb-fill,.xp-fill').forEach(b => {
            const w = b.style.width;
            b.style.width = '0';
            setTimeout(() => (b.style.width = w), 100);
          });
        }
      });
    }, { threshold: 0.3 });

    panels.forEach(p => observer.observe(p));
  }

  // Personalizar dashboard com dados do usuário logado
  if (window.__ME__) {
    const name = window.__ME__?.profile?.full_name || window.__ME__?.email || 'Aluno';

    // topbar hello
    const h1 = document.querySelector('#tab-home .dash-topbar h1');
    if (h1) h1.textContent = `👋 Olá, ${name.split(' ')[0]}!`;

    // sidebar avatar
    const av = document.querySelector('.sb-user .u-av');
    if (av) av.textContent = name.trim().slice(0,1).toUpperCase();

    // sidebar info
    const sbName = document.querySelector('.sb-user .u-info strong');
    if (sbName) sbName.textContent = name;

    const sbEmail = document.querySelector('.sb-user .u-info span');
    if (sbEmail) sbEmail.textContent = window.__ME__?.email || '';
  }

  // Perfil: salvar (conecta no backend)
  const btnSave = document.querySelector('#tab-perfil .save-btn');
  if (btnSave) {
    btnSave.addEventListener('click', async (ev) => {
      ev.preventDefault();
      try {
        const full_name = (document.querySelector('#tab-perfil input[placeholder="Nome Completo"]')?.value || '').trim();
        const phone = (document.querySelector('#tab-perfil input[placeholder="Telefone"]')?.value || '').trim();
        const res = await fetch('/api/profile', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf() },
          body: JSON.stringify({ full_name, phone })
        });
        const out = await res.json();
        if (!res.ok || !out.ok) throw new Error(out.error || 'Falha ao salvar');
        toast('ok','Perfil','Salvo com sucesso!');
      } catch (e) {
        toast('err','Perfil', e.message || 'Erro ao salvar');
      }
    });
  }

  // Senha: atualizar (conecta no backend)
  const btnPass = document.querySelector('#tab-perfil button.save-btn[style*="Atualizar senha"], #tab-perfil button.save-btn');
  // O HTML original tem 2 botões .save-btn (salvar e atualizar). Vamos pegar o segundo por posição.
  const passBtn = document.querySelectorAll('#tab-perfil .save-btn')[1];
  if (passBtn) {
    passBtn.addEventListener('click', async (ev) => {
      ev.preventDefault();
      try {
        const current_password = (document.querySelector('#tab-perfil input[placeholder="Senha atual"]')?.value || '');
        const new_password = (document.querySelector('#tab-perfil input[placeholder="Nova senha"]')?.value || '');
        const res = await fetch('/api/password', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf() },
          body: JSON.stringify({ current_password, new_password })
        });
        const out = await res.json();
        if (!res.ok || !out.ok) throw new Error(out.error || 'Falha ao atualizar senha');
        toast('ok','Senha','Atualizada com sucesso!');
      } catch (e) {
        toast('err','Senha', e.message || 'Erro');
      }
    });
  }
})();
